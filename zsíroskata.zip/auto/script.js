function red() {
    document.getElementById("red").src="images/m3red.jpg";
}

function white() {
    document.getElementById("white").src="images/m3white.jpg";
}

function blue() {
    document.getElementById("blue").src="images/m3blue.jpg";
}

//nem tudom :'(